import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score

# Load the dataset
data = pd.read_csv(r'final_weather_data.csv')
print(data.shape)
# Convert 'WeatherCondition' to numerical using one-hot encoding
data = pd.get_dummies(data, columns=['WeatherCondition'], drop_first=True)

# Extract features and target variable
X = data.drop('Severity', axis=1)
y = data['Severity']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Feature Scaling
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Create a Random Forest Classifier
rf_classifier = RandomForestClassifier(n_estimators=100, random_state=42)

# Train the model
rf_classifier.fit(X_train_scaled, y_train)

# Make predictions on the test set
y_pred = rf_classifier.predict(X_test_scaled)

# Calculate accuracy
accuracy = accuracy_score(y_test, y_pred)
print('Accuracy:', accuracy)

# Cross-validation
cv_accuracy = cross_val_score(rf_classifier, X, y, cv=5, scoring='accuracy')
print('Cross-Validation Accuracy:', cv_accuracy.mean())
