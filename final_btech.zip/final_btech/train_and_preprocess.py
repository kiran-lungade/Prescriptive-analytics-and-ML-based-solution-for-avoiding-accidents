import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
import joblib

# Assuming 'Severity' is the target variable
file_path = 'final_weather_num_data.csv'
df = pd.read_csv(file_path)

X = df.drop('Severity', axis=1)
y = df['Severity']

# Create a Random Forest model
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)

# Create a pipeline to ensure preprocessing is applied during training
model_pipeline = make_pipeline(rf_model)

# Train the model
model_pipeline.fit(X, y)

# Save the trained model
joblib.dump(model_pipeline, 'model.pkl')

# Save preprocessing steps
imputer = SimpleImputer(strategy='mean')
X_imputed = imputer.fit_transform(X)

preprocessing_data = {
    'imputer': imputer,
    'numeric_features': X.columns.tolist()  # Save the column names as a list
}
joblib.dump(preprocessing_data, 'preprocessing.pkl')

print("Model and preprocessing steps saved successfully.")
