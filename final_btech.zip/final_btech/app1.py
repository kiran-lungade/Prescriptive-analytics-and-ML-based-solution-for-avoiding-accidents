import time
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import subprocess

class MyHandler(FileSystemEventHandler):
    def on_modified(self, event):
        print(f'Changes detected in {event.src_path}. Reloading...')
        subprocess.run(['python', 'app4.py'])

def start_file_observer():
    event_handler = MyHandler()
    observer = Observer()
    observer.schedule(event_handler, ".", recursive=False)
    observer.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()

# List of Flask application filenames
apps = ["app2.py", "app3.py", "app4.py", "app5.py"]

def run_flask_apps():
    for app in apps:
        subprocess.Popen(['python', app])

    # Your Flask application code
    from flask import Flask, render_template

    app = Flask(__name__)

    @app.route('/')
    def home():
        return render_template('home.html')

    app.run(debug=True)

if __name__ == "__main__":
    run_flask_apps()
    start_file_observer()











# from flask import Flask, render_template

# app = Flask(__name__)

# @app.route('/')
# def home():
#     return render_template('home.html')

# if __name__ == '__main__':
#     app.run(debug=True)
