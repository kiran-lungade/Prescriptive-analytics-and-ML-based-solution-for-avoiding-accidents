from flask import Flask, render_template, request, redirect, url_for, jsonify
import pandas as pd
import csv
import os

app = Flask(__name__)

@app.route('/')
def index():
    success_message = request.args.get('success_message')
    error_message = request.args.get('error_message')
    return render_template('twilio.html', success_message=success_message, error_message=error_message)

@app.route('/save_data', methods=['POST'])
def save_data():
    data = {
        'account_sid': request.form['account_sid'],
        'auth_token': request.form['auth_token'],
        'twilio_phone_number': request.form['twilio_phone_number'],
        'recipient_phone_number': '91' + request.form['recipient_phone_number'][2:],  # Adjust formatting
        'recipient_name': request.form['recipient_name'],
        'location': request.form['location']
    }

    # Check if the user already exists
    if user_already_exists(data['recipient_phone_number'], data['location']):
        return redirect(url_for('index', error_message="User already exist."))

    # Create a DataFrame from the form data
    df = pd.DataFrame(data, index=[0])

    # Check if the file exists
    file_exists = os.path.exists('twilio.csv')

    if file_exists:
        existing_data = pd.read_csv('twilio.csv')
        combined_data = pd.concat([df, existing_data]).reset_index(drop=True)
    else:
        combined_data = df

    # Write the combined data to CSV
    combined_data.to_csv('twilio.csv', index=False)

    return redirect(url_for('index', success_message="Successfully registered."))


def user_already_exists(phone_number, location):
    if os.path.exists('twilio.csv'):
        with open('twilio.csv', 'r', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                if row['recipient_phone_number'] == phone_number and row['location'] == location:
                    return True
    return False



@app.route('/edit_location', methods=['POST'])
def edit_location():
    recipient_phone_number = request.form.get('recipient_phone_number')
    new_location = request.form.get('new_location')

    # Check if recipient exists in the CSV
    recipient_exists, recipient_index, recipient_row = find_recipient(recipient_phone_number)

    if recipient_exists:
        # Update location
        recipient_row['location'] = new_location

        # Rewrite the updated CSV
        rows = []
        with open('twilio.csv', 'r', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            fieldnames = reader.fieldnames
            for i, row in enumerate(reader):
                if i == recipient_index:
                    rows.append(recipient_row)
                else:
                    rows.append(row)

        with open('twilio.csv', 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for row in rows:
                writer.writerow(row)

        return jsonify({'status': 'success', 'message': 'Location updated successfully'})

    else:
        return jsonify({'status': 'error', 'message': 'Recipient not registered'})

def find_recipient(phone_number):
    if os.path.exists('twilio.csv'):
        with open('twilio.csv', 'r', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            for i, row in enumerate(reader):
                if row['recipient_phone_number'] == phone_number:
                    return True, i, row
    return False, None, None





@app.route('/delete_record', methods=['POST'])
def delete_record():
    delete_recipient_phone_number = request.form.get('delete_recipient_phone_number')

    rows = []
    with open('twilio.csv', 'r', encoding='utf-8') as csvfile:  # Specify encoding as 'utf-8'
        reader = csv.DictReader(csvfile)
        fieldnames = reader.fieldnames
        for row in reader:
            if row['recipient_phone_number'] != delete_recipient_phone_number:
                rows.append(row)

    if len(rows) < len(pd.read_csv('twilio.csv')):
        with open('twilio.csv', 'w', newline='', encoding='utf-8') as csvfile:  # Specify encoding as 'utf-8'
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for row in rows:
                writer.writerow(row)
        return redirect(url_for('index', success_message="Successfully deleted."))
    else:
        return redirect(url_for('index', error_message="User does not exist."))

if __name__ == '__main__':
    app.run(debug=True, port=5004)