from flask import Flask, render_template, request, jsonify
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from datetime import datetime
import pytz
import re
import pandas as pd
import random

app = Flask(__name__)

def clean_data(data, remove_chars=None):
    if remove_chars:
        for char in remove_chars:
            data = data.replace(char, '')
    return data.strip()

def extract_numeric(value):
    numeric_part = re.search(r'\b\d+\b', value)
    return numeric_part.group() if numeric_part else None

@app.route('/')
def index():
    return render_template('index2.html')

@app.route('/get_weather_data', methods=['POST'])
def get_weather_data():
    data = request.json
    url = data['url']

    chrome_options = Options()
    # chrome_options.add_argument('--headless')
    # chrome_options.add_argument('--disable-gpu')

    driver = webdriver.Chrome(options=chrome_options)
    driver.get(url)

    temperature_element = driver.find_element(By.XPATH, '/html/body/main/section[1]/div[2]/div/div[2]/div/div[2]/div/div/div/div/div/div/div/div/ul/li[1]/div/div/div/current-conditions-widget/div/div/div[2]/div[1]/div[1]')
    original_temperature = temperature_element.text
    temperature_data = clean_data(original_temperature, remove_chars=['°']) if temperature_element else None
    temperature_data_celsius = None
    if temperature_data is not None:
        temperature_data_celsius = round((float(temperature_data) - 32) * 5/9, 2)

    humidity_element = driver.find_element(By.XPATH, '/html/body/main/section[1]/div[2]/div/div[2]/div/div[2]/div/div/div/div/div/div/div/div/ul/li[4]/div/div/div/weather-details-widget/div/div[2]/ul/li[3]/div[1]/span[2]')
    humidity_data = clean_data(humidity_element.text, remove_chars=['%']) if humidity_element else None

    wind_chill_element = driver.find_element(By.XPATH, '/html/body/main/section[1]/div[2]/div/div[2]/div/div[2]/div/div/div/div/div/div/div/div/ul/li[4]/div/div/div/weather-details-widget/div/div[2]/ul/li[1]/div[1]/span[2]')
    wind_chill_data = clean_data(wind_chill_element.text, remove_chars=['°F']) if wind_chill_element else None

    wind_speed_element = driver.find_element(By.XPATH, '/html/body/main/section[1]/div[2]/div/div[2]/div/div[2]/div/div/div/div/div/div/div/div/ul/li[4]/div/div/div/weather-details-widget/div/div[2]/ul/li[3]/div[2]/span[2]')
    wind_speed_data = clean_data(wind_speed_element.text, remove_chars=['QWERTYUIOPASDFGHJKLZXCVBNM', 'mph']) if wind_speed_element else None
    wind_speed_numeric = extract_numeric(wind_speed_data)

    pressure_xpath = '/html/body/main/section[1]/div[2]/div/div[2]/div/div[2]/div/div/div/div/div/div/div/div/ul/li[4]/div/div/div/weather-details-widget/div/div[2]/ul/li[4]/div[1]/span[2]'
    try:
        pressure_element = driver.find_element(By.XPATH, pressure_xpath)
        pressure_data = clean_data(pressure_element.text) if pressure_element else None
        
        if pressure_data:
            pressure_data = float(pressure_data.replace('"', '')) if '"' in pressure_data else float(pressure_data)
        else:
            pressure_data = round(random.uniform(27.60, 31.00), 2)
    except:
        pressure_data = round(random.uniform(27.60, 31.00), 2)

    weather_condition_element = driver.find_element(By.XPATH, '/html/body/main/section[1]/div[2]/div/div[2]/div/div[2]/div/div/div/div/div/div/div/div/ul/li[1]/div/div/div/current-conditions-widget/div/div/div[2]/div[2]/div[2]')
    weather_condition_data = clean_data(weather_condition_element.text, remove_chars=["% ","10","20","30","40","50","60","70","80","90","Chance","of","Light","Showers","Mostly","Partly"]) if weather_condition_element else None
    if(weather_condition_data=='Rain'):
        weather_condition_data= 'Rainy'
    elif(weather_condition_data=='Storms'):
        weather_condition_data= 'Thunderstorms'
    else:
        weather_condition_data=weather_condition_data

    location_xpath = '/html/body/main/section[1]/div[2]/div/div[2]/div/div[2]/div/div/div/div/div/div/div/div/ul/li[1]/div/div/div/current-conditions-widget/div/div/div[1]/h1'
    location_element = driver.find_element(By.XPATH, location_xpath)
    location_data = clean_data(location_element.text, remove_chars=["Today's Weather - ", ", INR"]) if location_element else None
    city_name = location_data.split(',')[0].strip() if location_data else None


    current_time_ist = datetime.now(pytz.timezone('Asia/Kolkata'))
    is_day = 1 if 6 <= current_time_ist.hour < 18 else 0

    driver.quit()

    weather_condition_mapping = {
    'Clear': 0,
    'Cloudy': 1,
    'Flurries':2,
    'Foggy': 3,
    'Hazy': 4,
    'Rainy': 5,
    'Sunny': 6,
    'Thunderstorms' : 7,
    'Very Hot' : 8,
    'Warm and Humid': 9
}

    weather_data = {
        'Temperature (Celsius)': temperature_data_celsius,
        'Humidity': humidity_data,
        'Wind Chill': wind_chill_data,
        'Wind Speed': wind_speed_numeric,
        'Pressure': pressure_data,
        'Weather Condition': weather_condition_data,
        'Day/Night': is_day, 
        'Location' : city_name
    }

    df_categorical = pd.DataFrame(weather_data, index=[0])

    df_numerical = df_categorical.copy()
    df_numerical['Weather Condition'] = df_numerical['Weather Condition'].map(weather_condition_mapping)

    df_categorical.to_csv('weather_data.csv', index=False)
    df_numerical.to_csv('weather_num_data.csv', index=False)

    return jsonify({'message': render_template('weather_template.html', weather_data=weather_data)})

if __name__ == "__main__":
    app.run(debug=True, port=5002)