from flask import Flask, render_template, request, redirect, url_for
import joblib
import pandas as pd

app = Flask(__name__)

model = joblib.load('model.pkl')
preprocessing_data = joblib.load('preprocessing.pkl')

imputer = preprocessing_data.get('imputer')
numeric_features = preprocessing_data.get('numeric_features')

if imputer is None or numeric_features is None:
    raise ValueError("Error loading preprocessing data. Please check the preprocessing.pkl file.")

@app.route('/')
def home():
    return render_template('index.html', prediction=None)

@app.route('/predict', methods=['POST'])
def predict():

    location= 'Remote'
    
    input_data = {
            'Temperature(C)': [float(request.form['temperature'])],
            'Humidity(%)': [float(request.form['humidity'])],
            'WindChill(F)': [float(request.form['windchill'])],
            'WindSpeed(mph)': [float(request.form['windspeed'])],
            'Pressure(in)': [float(request.form['pressure'])],
            'WeatherCondition': [request.form['weather_condition']],
            'Day/Night': [request.form['day_night']],
        }

    input_df = pd.DataFrame(input_data)

    input_df[numeric_features] = imputer.transform(input_df[numeric_features])

    severity_prediction = model.predict(input_df)

    temperature = float(request.form['temperature'])
    speed = float(request.form['windspeed'])
    chill = float(request.form['windchill'])
    pressure = float(request.form['pressure'])
    humidity = float(request.form['humidity'])
    dn = int(request.form['day_night'])

    return redirect(url_for('result', prediction=severity_prediction[0], location=location, temperature=temperature, humidity=humidity, chill=chill, pressure=pressure, dn=dn, speed=speed))

@app.route('/result')
def result():
    prediction = request.args.get('prediction')
    location = request.args.get('location')
    temperature = request.args.get('temperature')
    humidity = request.args.get('humidity')
    chill = request.args.get('chill')
    speed = request.args.get('speed')
    pressure = request.args.get('pressure')
    dn = request.args.get('dn')
    return render_template('result.html', prediction=prediction, location=location, temperature=temperature, chill=chill, humidity=humidity, pressure=pressure, dn=dn, speed=speed)

if __name__ == '__main__':
    app.run(debug=True, port=5001)
