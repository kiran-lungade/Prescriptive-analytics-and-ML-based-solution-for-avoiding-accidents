from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
import joblib
from twilio.rest import Client
from twilio.base.exceptions import TwilioRestException
import logging

app = Flask(__name__)

# Load the trained model and preprocessing steps
model = joblib.load('model.pkl')
preprocessing_data = joblib.load('preprocessing.pkl')

# Load Twilio data
twilio_data = pd.read_csv('twilio.csv')

# Dictionary to store Twilio clients by account_sid
clients = {row['account_sid']: Client(row['account_sid'], row['auth_token']) for _, row in twilio_data.iterrows()}

# Function to preprocess input data
def preprocess_data(data):
    # Create a DataFrame from the input data
    input_df = pd.DataFrame(data, index=[0])

    # Rename columns to match the columns used during training
    input_df = input_df.rename(columns={
        'Temperature (Celsius)': 'Temperature(C)',
        'Humidity': 'Humidity(%)',
        'Wind Chill': 'WindChill(F)',
        'Wind Speed': 'WindSpeed(mph)',
        'Pressure': 'Pressure(in)',
        'Weather Condition': 'WeatherCondition',
        'Day/Night': 'Day/Night'
    })

    # Use the same columns as during training
    input_df = input_df[preprocessing_data['numeric_features']]

    # Apply the saved preprocessing steps
    input_df = preprocessing_data['imputer'].transform(input_df)

    return input_df

def get_latest_weather_data():
    # Load data from CSV file
    csv_file_path = 'weather_num_data.csv'
    df = pd.read_csv(csv_file_path)

    # Take the latest row for prediction
    latest_data = df.iloc[-1].to_dict()

    location = latest_data.get('Location', 'Unknown Location')

    return latest_data, location

@app.route('/')
def index():
    severity_description = {
        1: "Safe to go✅✅. Enjoy the journey.",
        2: "Minor or moderate injuries ☹️, but no hospitalization 🥶🥶🥶. So, take care and travel safely😊.",
        3: "🚨🚨 Alert 🚨🚨 Serious or life-threatening injuries that require hospitalization🥺🥺. So drive or travel safely.💨💨",
        4: "🚨🚨  Alert  🚨🚨 A higher level of severity🥵🥵, usually involving multiple fatalities or severe injuries😭😭. It is risky to travel. If needed travel safely and slowly🚗🚌."
    }

    try:
        weather_data, location = get_latest_weather_data()

        input_df = preprocess_data(weather_data)

        severity_prediction = model.predict(input_df)[0]

        recipient_names = dict(zip(twilio_data['recipient_phone_number'], twilio_data['recipient_name']))
        recipients_for_location = twilio_data[twilio_data['location'] == location]

        for _, row in recipients_for_location.iterrows():
            client = clients[row['account_sid']]
            recipient_phone_number = row['recipient_phone_number']
            recipient_name = recipient_names.get(recipient_phone_number, "Unknown Recipient")
            severity_description_text = severity_description.get(severity_prediction, "Unknown severity")
            
            try:
                message = client.messages.create(
                    body=f"\n \nHello {recipient_name}.\n Accident Severity Prediction at {location}: {severity_prediction} - \n{severity_description_text}\n \nThank You!!",
                    from_=row['twilio_phone_number'],
                    to=recipient_phone_number
                )

                call = client.calls.create(
                    twiml=f'<Response><Say voice="woman" language="en">Hello {recipient_name}. Accident Severity Prediction at {location} is {severity_prediction}. {severity_description_text}. Please follow all rules. A small mistake, can lead to huge loss. Drive or travel safely. Your safety is our safety. Thank you!</Say></Response>',
                    to=recipient_phone_number,
                    from_=row['twilio_phone_number']
                )
            except TwilioRestException as e:
                logging.error(f"Twilio error: {e}")

        return redirect(url_for('result', prediction=severity_prediction, location=location, temperature=weather_data['Temperature (Celsius)'], humidity=weather_data['Humidity'], pressure=weather_data['Pressure'], speed=weather_data['Wind Speed'], chill=weather_data['Wind Chill'], dn=weather_data['Day/Night']))

    except TwilioRestException as e:
        logging.error(f"Twilio error: {e}")
        return redirect(url_for('result', prediction=severity_prediction, location=location, temperature=weather_data['Temperature (Celsius)'], humidity=weather_data['Humidity'], pressure=weather_data['Pressure'], speed=weather_data['Wind Speed'], chill=weather_data['Wind Chill'], dn=weather_data['Day/Night']))

@app.route('/result')
def result():
    prediction = request.args.get('prediction')
    pressure = request.args.get('pressure')
    location = request.args.get('location')
    temperature = request.args.get('temperature')
    humidity = request.args.get('humidity')
    speed = request.args.get('speed')
    chill = request.args.get('chill')
    dn = request.args.get('dn')
    return render_template('result.html', prediction=prediction, location=location, temperature=temperature, humidity=humidity, pressure=pressure, speed=speed, chill=chill, dn=dn)

if __name__ == '__main__':
    app.run(debug=True, port=5003)





















# from flask import Flask, render_template, request, redirect, url_for
# import pandas as pd
# import joblib
# from twilio.rest import Client
# from twilio.base.exceptions import TwilioRestException
# import logging

# app = Flask(__name__)

# # Load the trained model and preprocessing steps
# model = joblib.load('model.pkl')
# preprocessing_data = joblib.load('preprocessing.pkl')

# # Twilio credentials
# account_sid_list = ['AC4b403e6bb76a942f246862c2fc14f8c9', 'ACd5b9c3dffcc54d131e03cc7ea6ad2193', 'AC125e459ede952dd44e39b79bd724eb1f', 'AC5f59929501963cee098e6f37fa4edd18']
# auth_token_list = ['20d52964169b1dc7548f93b1988974ec', 'a36e14abcafef5f8c6fe665c8beea767', '8b7047f2575441a89c2ef1ed23ff14a0', 'a448701a68e87311e13e9e5a1be1b754']
# twilio_phone_number_list = ['+12512748569', '+12062030878', '+15103425963', '+18155156575']
# recipient_phone_number_list = ['+917498776512', '+918605472551', '+919325178248', '+919960506953']

# clients = [Client(account_sid, auth_token) for account_sid, auth_token in zip(account_sid_list, auth_token_list)]

# # Function to preprocess input data
# def preprocess_data(data):
#     # Create a DataFrame from the input data
#     input_df = pd.DataFrame(data, index=[0])

#     # Rename columns to match the columns used during training
#     input_df = input_df.rename(columns={
#         'Temperature (Celsius)': 'Temperature(C)',
#         'Humidity': 'Humidity(%)',
#         'Wind Chill': 'WindChill(F)',
#         'Wind Speed': 'WindSpeed(mph)',
#         'Pressure': 'Pressure(in)',
#         'Weather Condition': 'WeatherCondition',
#         'Day/Night': 'Day/Night'
#     })

#     # Use the same columns as during training
#     input_df = input_df[preprocessing_data['numeric_features']]

#     # Apply the saved preprocessing steps
#     input_df = preprocessing_data['imputer'].transform(input_df)

#     return input_df

# def get_latest_weather_data():
#     # Load data from CSV file
#     csv_file_path = 'weather_num_data.csv'
#     df = pd.read_csv(csv_file_path)

#     # Take the latest row for prediction
#     latest_data = df.iloc[-1].to_dict()

#     location = latest_data.get('Location', 'Unknown Location')

#     return latest_data, location

# @app.route('/')
# def index():
#     severity_description = {
#         1: "Safe to go✅✅. Enjoy the journey.",
#         2: "Minor or moderate injuries ☹️, but no hospitalization 🥶🥶🥶. So, take care and travel safely😊.",
#         3: "🚨🚨 Alert 🚨🚨 Serious or life-threatening injuries that require hospitalization🥺🥺. So drive or travel safely.💨💨",
#         4: "🚨🚨  Alert  🚨🚨 A higher level of severity🥵🥵, usually involving multiple fatalities or severe injuries😭😭. It is risky to travel. If needed travel safely and slowly🚗🚌."
#     }

#     recipient_names = {
#     "+917498776512": "Kiran Lungade",
#     "+918605472551": "Vaishnavi Aher",
#     "+919325178248": "Arati Rahane",
#     "+919960506953": "Priyanka Rahane"
#     }


#     try:
#         for client, twilio_phone_number, recipient_phone_number in zip(clients, twilio_phone_number_list, recipient_phone_number_list):
            
#             weather_data, location = get_latest_weather_data()

#             input_df = preprocess_data(weather_data)

#             severity_prediction = model.predict(input_df)

#             recipient_name = recipient_names.get(recipient_phone_number, "Unknown Recipient")
            
#             severity_description_text = severity_description.get(severity_prediction[0], "Unknown severity")

#             message = client.messages.create(
#                     body=f"\n \nHello {recipient_name}.\n Accident Severity Prediction at {location}: {severity_prediction[0]} - \n{severity_description_text}\n \nThank You!!",
#                     from_=twilio_phone_number,
#                     to=recipient_phone_number
#                 )

#             # if location in ['Ahmadnagar', 'Akola', 'Igatpuri', 'Kopargaon', 'Lonavala', 'Mahabaleshwar', 'Mumbai', 'Nashik', 'Pune', 
#             #                 'Ratnagiri', 'Sangamner', 'Shirdi', 'Thane', 'Vaijapur', 'Yavatmal', 'Yeola']:
#             #     message = client.messages.create(
#             #         body=f"\n \nHello {recipient_name}.\n Accident Severity Prediction at {location}: {severity_prediction[0]} - \n{severity_description_text}\n \nThank You!!",
#             #         from_=twilio_phone_number,
#             #         to='+917498776512'
#             #     )
                    
#             #     # call = client.calls.create(
#             #     #     twiml=f'<Response><Say voice="man" language="en">Hello {recipient_name}. Accident Severity Prediction at {location} is {severity_prediction[0]}. {severity_description_text}. Please follow all rules. A small mistake, can lead to huge lost. Drive or travel safely. Your safety is our safety. Thank you!</Say></Response>',
#             #     #     to='+917498776512',
#             #     #     from_=twilio_phone_number
#             #     #     )
                
#             # if location in ['Ajmer', 'Jaipur', 'Jaisalmer', 'Jodhpur', 'Kota', 'Udaipur', 'Haridwar', 'Kashipur', 'Agra', 'Ayodhya', 
#             #                 'Dehradun', 'Ghaziabad', 'Jhansi', 'Kanpur', 'Lucknow', 'Mathura', 'Meerut', 'Varanasi']:
#             #     message = client.messages.create(
#             #         body=f"\n \nHello {recipient_name}.\n Accident Severity Prediction at {location}: {severity_prediction[0]} - \n{severity_description_text}\n \nThank You!!",
#             #         from_=twilio_phone_number,
#             #         to='+918605472551'
#             #     )

#             #     # call = client.calls.create(
#             #     #     twiml=f'<Response><Say voice="man" language="en">Hello {recipient_name}. Accident Severity Prediction at {location} is {severity_prediction[0]}. {severity_description_text}. Please follow all rules. A small mistake, can lead to huge lost. Drive or travel safely. Your safety is our safety. Thank you!</Say></Response>',
#             #     #     to='+918605472551',
#             #     #     from_=twilio_phone_number
#             #     #     )

#             # if location in ['Gangtok', 'Kochi', 'Thiruvananthapuram', 'Chennai', 'Coimbatore', 'Kanchipuram', 'Ahmadabad', 'Rajkot', 
#             #                 'Surat', 'Mawsynram', 'Shillong', 'Agartala', 'Amarpur', 'Panaji', 'Ponda', 'New Delhi', 'Calcutta', 'Darjiling']:
#             #     message = client.messages.create(
#             #         body=f"\n \nHello {recipient_name}.\n Accident Severity Prediction at {location}: {severity_prediction[0]} - \n{severity_description_text}\n \nThank You!!",
#             #         from_=twilio_phone_number,
#             #         to='+919325178248'
#             #     )
                    
#             #     # call = client.calls.create(
#             #     #     twiml=f'<Response><Say voice="man" language="en">Hello {recipient_name}. Accident Severity Prediction at {location} is {severity_prediction[0]}. {severity_description_text}. Please follow all rules. A small mistake, can lead to huge lost. Drive or travel safely. Your safety is our safety. Thank you!</Say></Response>',
#             #     #     to='+919325178248',
#             #     #     from_=twilio_phone_number
#             #     #     )
                
#             # else:
#             #     message = client.messages.create(
#             #         body=f"\n \nHello {recipient_name}.\n Accident Severity Prediction at {location}: {severity_prediction[0]} - \n{severity_description_text}\n \nThank You!!",
#             #         from_=twilio_phone_number,
#             #         to='+919960506953'
#             #     )
                    
#             #     # call = client.calls.create(
#             #     #     twiml=f'<Response><Say voice="man" language="en">Hello {recipient_name}. Accident Severity Prediction at {location} is {severity_prediction[0]}. {severity_description_text}. Please follow all rules. A small mistake, can lead to huge lost. Drive or travel safely. Your safety is our safety. Thank you!</Say></Response>',
#             #     #     to='+919960506953',
#             #     #     from_=twilio_phone_number
#             #     #     )

#         return redirect(url_for('result', prediction=severity_prediction[0], location=location, temperature=weather_data['Temperature (Celsius)'], humidity=weather_data['Humidity'], pressure=weather_data['Pressure'], speed= weather_data['Wind Speed'], chill=weather_data['Wind Chill'], dn= weather_data['Day/Night']))

#     except TwilioRestException as e:
#         return redirect(url_for('result', prediction=severity_prediction[0], location=location, temperature=weather_data['Temperature (Celsius)'], humidity=weather_data['Humidity'], pressure=weather_data['Pressure'], speed= weather_data['Wind Speed'], chill=weather_data['Wind Chill'], dn= weather_data['Day/Night']))

# @app.route('/result')
# def result():
#     prediction = request.args.get('prediction')
#     pressure = request.args.get('pressure')
#     location = request.args.get('location')
#     temperature = request.args.get('temperature')
#     humidity = request.args.get('humidity')
#     speed = request.args.get('speed')
#     chill = request.args.get('chill')
#     dn = request.args.get('dn')
#     return render_template('result.html', prediction=prediction, location=location, temperature=temperature, humidity=humidity, pressure=pressure, speed=speed, chill=chill, dn=dn)

# if __name__ == '__main__':
#     app.run(debug=True, port=5003)














# from flask import Flask, render_template, request, redirect, url_for
# import pandas as pd
# import joblib
# from twilio.rest import Client
# from twilio.base.exceptions import TwilioRestException
# import logging

# app = Flask(__name__)

# # Load the trained model and preprocessing steps
# model = joblib.load('model.pkl')
# preprocessing_data = joblib.load('preprocessing.pkl')

# # Twilio credentials
# twilio_data = pd.read_csv('twilio.csv')

# clients = [Client(row['account_sid'], row['auth_token']) for _, row in twilio_data.iterrows()]

# # Function to preprocess input data
# def preprocess_data(data):
#     # Create a DataFrame from the input data
#     input_df = pd.DataFrame(data, index=[0])

#     # Rename columns to match the columns used during training
#     input_df = input_df.rename(columns={
#         'Temperature (Celsius)': 'Temperature(C)',
#         'Humidity': 'Humidity(%)',
#         'Wind Chill': 'WindChill(F)',
#         'Wind Speed': 'WindSpeed(mph)',
#         'Pressure': 'Pressure(in)',
#         'Weather Condition': 'WeatherCondition',
#         'Day/Night': 'Day/Night'
#     })

#     # Use the same columns as during training
#     input_df = input_df[preprocessing_data['numeric_features']]

#     # Apply the saved preprocessing steps
#     input_df = preprocessing_data['imputer'].transform(input_df)

#     return input_df

# def get_latest_weather_data():
#     # Load data from CSV file
#     csv_file_path = 'weather_num_data.csv'
#     df = pd.read_csv(csv_file_path)

#     # Take the latest row for prediction
#     latest_data = df.iloc[-1].to_dict()

#     location = latest_data.get('Location', 'Unknown Location')

#     return latest_data, location

# @app.route('/')
# def index():
#     severity_description = {
#         1: "Safe to go✅✅. Enjoy the journey.",
#         2: "Minor or moderate injuries ☹️, but no hospitalization 🥶🥶🥶. So, take care and travel safely😊.",
#         3: "🚨🚨 Alert 🚨🚨 Serious or life-threatening injuries that require hospitalization🥺🥺. So drive or travel safely.💨💨",
#         4: "🚨🚨  Alert  🚨🚨 A higher level of severity🥵🥵, usually involving multiple fatalities or severe injuries😭😭. It is risky to travel. If needed travel safely and slowly🚗🚌."
#     }

#     try:
#         weather_data, location = get_latest_weather_data()

#         input_df = preprocess_data(weather_data)

#         severity_prediction = model.predict(input_df)

#         recipient_names = dict(zip(twilio_data['recipient_phone_number'], twilio_data['recipient_name']))

#         for client, row in zip(clients, twilio_data.iterrows()):
#             row = row[1]  # Extracting row data from the iterator
#             if row['location'] == location:
#                 recipient_phone_number = row['recipient_phone_number']
#                 recipient_name = recipient_names.get(recipient_phone_number, "Unknown Recipient")
#                 severity_description_text = severity_description.get(severity_prediction[0], "Unknown severity")
                
#                 message = client.messages.create(
#                     body=f"\n \nHello {recipient_name}.\n Accident Severity Prediction at {location}: {severity_prediction[0]} - \n{severity_description_text}\n \nThank You!!",
#                     from_=row['twilio_phone_number'],
#                     to=recipient_phone_number
#                 )

#         return redirect(url_for('result', prediction=severity_prediction[0], location=location, temperature=weather_data['Temperature (Celsius)'], humidity=weather_data['Humidity'], pressure=weather_data['Pressure'], speed= weather_data['Wind Speed'], chill=weather_data['Wind Chill'], dn= weather_data['Day/Night']))

#     except TwilioRestException as e:
#         return redirect(url_for('result', prediction=severity_prediction[0], location=location, temperature=weather_data['Temperature (Celsius)'], humidity=weather_data['Humidity'], pressure=weather_data['Pressure'], speed= weather_data['Wind Speed'], chill=weather_data['Wind Chill'], dn= weather_data['Day/Night']))

# @app.route('/result')
# def result():
#     prediction = request.args.get('prediction')
#     pressure = request.args.get('pressure')
#     location = request.args.get('location')
#     temperature = request.args.get('temperature')
#     humidity = request.args.get('humidity')
#     speed = request.args.get('speed')
#     chill = request.args.get('chill')
#     dn = request.args.get('dn')
#     return render_template('result.html', prediction=prediction, location=location, temperature=temperature, humidity=humidity, pressure=pressure, speed=speed, chill=chill, dn=dn)

# if __name__ == '__main__':
#     app.run(debug=True, port=5003)



















# from flask import Flask, render_template, request, redirect, url_for
# import pandas as pd
# import joblib

# app = Flask(__name__)

# # Load the trained model and preprocessing steps
# model = joblib.load('model.pkl')
# preprocessing_data = joblib.load('preprocessing.pkl')

# # Function to preprocess input data
# def preprocess_data(data):
#     # Create a DataFrame from the input data
#     input_df = pd.DataFrame(data, index=[0])

#     # Rename columns to match the columns used during training
#     input_df = input_df.rename(columns={
#         'Temperature (Celsius)': 'Temperature(C)',
#         'Humidity': 'Humidity(%)',
#         'Wind Chill': 'WindChill(F)',
#         'Wind Speed': 'WindSpeed(mph)',
#         'Pressure': 'Pressure(in)',
#         'Weather Condition': 'WeatherCondition',
#         'Day/Night': 'Day/Night'
#     })

#     # Use the same columns as during training
#     input_df = input_df[preprocessing_data['numeric_features']]

#     # Apply the saved preprocessing steps
#     input_df = preprocessing_data['imputer'].transform(input_df)

#     return input_df

# def get_latest_weather_data():
#     # Load data from CSV file
#     csv_file_path = 'weather_num_data.csv'
#     df = pd.read_csv(csv_file_path)

#     # Take the latest row for prediction
#     latest_data = df.iloc[-1].to_dict()

#     location = latest_data.get('Location', 'Unknown Location')

#     return latest_data, location

# @app.route('/')
# def index():
#     weather_data, location = get_latest_weather_data()

#             # Preprocess the input data
#     input_df = preprocess_data(weather_data)

#     severity_prediction = model.predict(input_df)

#         # Redirect to the result page with the prediction
#     return redirect(url_for('result', prediction=severity_prediction[0], location=location, temperature=weather_data['Temperature (Celsius)'], humidity=weather_data['Humidity'], pressure=weather_data['Pressure'], speed= weather_data['Wind Speed'], chill=weather_data['Wind Chill'], dn= weather_data['Day/Night']))

#     # except Exception as e:
#     #     return render_template('index.html', prediction='Error: Please check your inputs.')

# # Render the result page
# @app.route('/result')
# def result():
#     prediction = request.args.get('prediction')
#     pressure = request.args.get('pressure')
#     location = request.args.get('location')
#     temperature = request.args.get('temperature')
#     humidity = request.args.get('humidity')
#     speed = request.args.get('speed')
#     chill = request.args.get('chill')
#     dn = request.args.get('dn')
#     return render_template('result.html', prediction=prediction, location=location, temperature=temperature, humidity=humidity, pressure=pressure, speed=speed, chill=chill, dn=dn)

# if __name__ == '__main__':
#     app.run(debug=True, port=5003)
