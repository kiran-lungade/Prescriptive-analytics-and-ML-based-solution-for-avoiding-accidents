import pandas as pd
from sklearn.preprocessing import LabelEncoder

df = pd.read_csv('final_weather_data.csv')

# Use Label Encoding for 'WeatherCondition' column
label_encoder = LabelEncoder()
df['WeatherCondition'] = label_encoder.fit_transform(df['WeatherCondition'])

# Display the mapping of original values to numeric labels
weather_condition_mapping = dict(zip(label_encoder.classes_, label_encoder.transform(label_encoder.classes_)))
print("WeatherCondition Mapping:")
for weather, label in weather_condition_mapping.items():
    print(f"{weather}: {label}")

# Save the numerical data to a new CSV file
output_file_path = 'final_weather_num_data.csv'
df.to_csv(output_file_path, index=False)

print(f"Data successfully converted and saved to {output_file_path}")
